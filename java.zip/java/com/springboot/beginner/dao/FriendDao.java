package com.springboot.beginner.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springboot.beginner.entity.FriendEntity;
import com.springboot.beginner.pojo.Friend;
import com.springboot.beginner.repository.FriendRepository;

@Repository
public class FriendDao {
	
	@Autowired
	private FriendRepository friendRepository;
	
	
	  public void saveFriend() { FriendEntity fe = new FriendEntity();
	  fe.setName("Rubesh");
	  fe.setAge("4"); 
	  friendRepository.save(fe);
	  
	  }
	 
	/*
	 * public List<Friend> saveFriend(int id, Friend friend) {
	 * 
	 * FriendEntity fe = new FriendEntity(); fe.setName(friend.getName());
	 * fe.setName(friend.getAge()); friendRepository.save(fe); List<FriendEntity>
	 * friendEntities = friendRepository.findAll(); List<Friend> allFriends = new
	 * ArrayList<Friend>(); for (FriendEntity feTemp : friendEntities) { Friend
	 * fTemp = new Friend(); fTemp.setId(feTemp.getId());
	 * fTemp.setName(feTemp.getName()); fTemp.setAge(feTemp.getAge());
	 * allFriends.add(fTemp);
	 * 
	 * } return allFriends;
	 * 
	 * }
	 */
	public List<FriendEntity> getAllFriends() {
		return friendRepository.findAll();
		
	}		
	public FriendEntity getAllFriendById(int id) {
		// TODO Auto-generated method stub
		return friendRepository.findById(id).get();
	}
	
	public List<Friend> updateFriendById(int id, Friend friend) {
		FriendEntity fe = new FriendEntity();
		fe.setId(id);
		fe.setName(friend.getName());
		fe.setAge(friend.getAge());			
		friendRepository.saveAndFlush(fe);
		List<FriendEntity> friendEntities = friendRepository.findAll();
		 List<Friend> allFriends = new ArrayList<Friend>();
		for (FriendEntity feTemp : friendEntities ) {
			Friend fTemp = new Friend();
			fTemp.setId(feTemp.getId());
			fTemp.setName(feTemp.getName());
			fTemp.setAge(feTemp.getAge());
			allFriends.add(fTemp);	
			}  		
				
		//return friendRepository.findAll();	
			return allFriends;	
	}	

}
