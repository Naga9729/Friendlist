package com.springboot.beginner.newcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.beginner.entity.FriendEntity;
import com.springboot.beginner.pojo.Friend;
import com.springboot.beginner.service.FriendService;

@RestController 
public class FriendController {
	
	@Autowired
	private FriendService friendservice;
	
	@RequestMapping("/welcome")
    public String welcome() {
    	return " <<<< Welcome to Spring Boot Data >>>> ";    	
    }
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public void saveFriend(@RequestBody Friend friend) {
		friendservice.savefriend(); 			
	}
	//@GetMapping("/all")
	public List<FriendEntity> getAllfriends() {
		return friendservice.getAllFriends();
	}
	
	@GetMapping("/get/{myid}")	
	public FriendEntity getAllFriendById(@PathVariable("myid") int id) {
			return friendservice.getAllFriendById(id);
		
	}	
	@PostMapping("/update/{myid}")
	//@PostMapping(value="/update/{myid}", method=RequestMethod.POST)
	public List<Friend> updateFriendById (@PathVariable("myid") int id,@RequestBody Friend friend ) {
		return friendservice.updateFriendById(id, friend); 
		
	}
	
}
