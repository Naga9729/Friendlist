package com.springboot.beginner.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.springboot.beginner.dao.FriendDao;
import com.springboot.beginner.entity.FriendEntity;
import com.springboot.beginner.pojo.Friend;
 
@Service
public class FriendService {
	@Autowired
	private FriendDao friendDao;

	public void savefriend() {
		
		friendDao.saveFriend();
	}

	public List<FriendEntity> getAllFriends() {
     return friendDao.getAllFriends();
		
	}
	
	@Cacheable("friendentity")
	public FriendEntity getAllFriendById(int id){
		try {
			System.out.println("###########");
			System.out.println("Sleep for 8 seconds");
			System.out.println("###########");
			
			Thread.sleep(8000);
			
		} catch (Exception e) {
			e.printStackTrace();
		}  		
	     return friendDao.getAllFriendById(id);
			
		}


	public List<Friend> updateFriendById(int id, Friend friend) {
		return friendDao.updateFriendById(id, friend); 
		
	}
	

}
